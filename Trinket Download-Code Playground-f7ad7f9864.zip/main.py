
### Use this space to try out ideas and free code ###

def ops(i,x,y):
  
  if i==1:
    
    return x+y
    
  if i==2:
    
    return x-y
    
  if i==3:
    
    return x*y
    
  if i==4:
    
    return x/y
    
def main():
  
  print(ops(1,858585,5585858))
  
  print(ops(2,88585858,5585858))
  
  print(ops(3,86858,55858585))
  
  print(ops(4,6790686,8989898))
  
  
  
  
main()